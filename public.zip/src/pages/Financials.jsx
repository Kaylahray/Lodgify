import React from "react";
import { Outlet, redirect, useNavigate } from "react-router-dom";

const Financials = () => {
  return <Outlet />;
};

export default Financials;
