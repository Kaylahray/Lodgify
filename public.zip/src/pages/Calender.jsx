// import React from "react";
import Calendar from "../features/calender/Calendar";

const Calender = () => {
  return <Calendar />;
}; 

export default Calender;
