import { useParams } from "react-router-dom";

const GuestProfile = () => {
  const { GuestProfile } = useParams();
  return <div></div>;
};

export default GuestProfile;
